angular.module('claimSwiftApp')
    .controller('UserDashboardController', ['$scope', '$window', '$interval', 'ClaimService', 'UserService',
        function($scope, $window, $interval, ClaimService, UserService) {
            
            // Get user from UserService first, fallback to sessionStorage
            $scope.user = UserService.getCurrentUser();
            if (!$scope.user) {
                try {
                    $scope.user = JSON.parse($window.sessionStorage.getItem('user'));
                } catch(e) {
                    $scope.user = null;
                }
            }
            
            $scope.imageFile = null;
            $scope.pdfFile = null;
            $scope.claims = [];
            $scope.submittingClaim = false;
            
            // Check if user is logged in
            if (!$scope.user) {
                $window.location.href = '../index.html';
                return;
            }
            
            // Load user claims
            $scope.loadClaims = function() {
                ClaimService.getClaimsByUser($scope.user.id).then(function(response) {
                    $scope.claims = response.data;
                });
            };
            
            // Initial load
            $scope.loadClaims();
            
            // Auto-refresh claims every 5 seconds for real-time updates
            var refreshInterval = $interval(function() {
                $scope.loadClaims();
            }, 5000);
            
            // Clean up interval on page leave
            $scope.$on('$destroy', function() {
                if (refreshInterval) {
                    $interval.cancel(refreshInterval);
                }
            });
            
            $scope.submitClaim = function() {
                if (!$scope.imageFile) {
                    alert('Please upload a vehicle damage image');
                    return;
                }
                
                $scope.submittingClaim = true;
                
                var formData = new FormData();
                formData.append('userId', $scope.user.id);
                formData.append('image', $scope.imageFile);
                if ($scope.pdfFile) {
                    formData.append('pdf', $scope.pdfFile);
                }
                
                ClaimService.createClaim(formData).then(function(response) {
                    alert('Claim submitted successfully!');
                    $scope.imageFile = null;
                    $scope.pdfFile = null;
                    $scope.submittingClaim = false;
                    $scope.loadClaims();
                    
                    // Reset file inputs
                    angular.element("input[type='file']").val(null);
                }, function(error) {
                    alert('Failed to submit claim: ' + (error.data.error || 'Unknown error'));
                    $scope.submittingClaim = false;
                });
            };
            
            $scope.logout = function() {
                UserService.logout();
                try {
                    $window.sessionStorage.clear();
                } catch(e) {
                    console.warn('Could not clear sessionStorage');
                }
                $window.location.href = '../index.html';
            };
        }
    ]);