angular.module('claimSwiftApp')
    .controller('ClaimDetailsController', ['$scope', '$window', '$location', 'ClaimService',
        function($scope, $window, $location, ClaimService) {
            
            $scope.user = JSON.parse($window.sessionStorage.getItem('user'));
            $scope.claim = null;
            $scope.parts = [{partName: '', amount: 0}];
            
            // Check if user is logged in and is an agent
            if (!$scope.user || $scope.user.role !== 'AGENT') {
                $window.location.href = '../index.html';
                return;
            }
            
            // Get claim ID from URL
            var urlParams = new URLSearchParams($window.location.search);
            var claimId = urlParams.get('id');
            
            if (!claimId) {
                alert('Invalid claim ID');
                $window.location.href = 'agent-dashboard.html';
                return;
            }
            
            // Load claim details
            ClaimService.getClaimById(claimId).then(function(response) {
                $scope.claim = response.data;
                
                // If claim already has parts, load them
                if ($scope.claim.claimParts && $scope.claim.claimParts.length > 0) {
                    $scope.parts = $scope.claim.claimParts.map(function(part) {
                        return {
                            partName: part.partName,
                            amount: part.amount
                        };
                    });
                }
            }, function(error) {
                alert('Failed to load claim details');
                $window.location.href = 'agent-dashboard.html';
            });
            
            $scope.addPart = function() {
                $scope.parts.push({partName: '', amount: 0});
            };
            
            $scope.removePart = function(index) {
                $scope.parts.splice(index, 1);
            };
            
            $scope.calculateTotal = function() {
return $scope.parts.reduce(function(sum, part) {
return sum + (parseFloat(part.amount) || 0);
}, 0);
};
$scope.isValidEstimation = function() {
            return $scope.parts.every(function(part) {
                return part.partName && part.partName.trim() !== '' && 
                       part.amount && part.amount > 0;
            });
        };
        
        $scope.approveClaim = function() {
            if (!$scope.isValidEstimation()) {
                alert('Please fill in all part names and amounts');
                return;
            }
            
            if (confirm('Are you sure you want to APPROVE this claim?')) {
                ClaimService.approveClaim(claimId, $scope.parts).then(function(response) {
                    alert('Claim approved successfully!');
                    $scope.claim = response.data.claim;
                }, function(error) {
                    alert('Failed to approve claim: ' + (error.data.error || 'Unknown error'));
                });
            }
        };
        
        $scope.disapproveClaim = function() {
            if (confirm('Are you sure you want to DISAPPROVE this claim?')) {
                ClaimService.disapproveClaim(claimId).then(function(response) {
                    alert('Claim disapproved!');
                    $scope.claim = response.data.claim;
                }, function(error) {
                    alert('Failed to disapprove claim: ' + (error.data.error || 'Unknown error'));
                });
            }
        };
        
        $scope.getImageUrl = function(imagePath) {
            return 'http://localhost:8080/uploads/' + imagePath;
        };
        
        $scope.getPdfUrl = function(pdfPath) {
            return 'http://localhost:8080/uploads/' + pdfPath;
        };
        
        $scope.goBack = function() {
            $window.location.href = 'agent-dashboard.html';
        };
    }
]);
            