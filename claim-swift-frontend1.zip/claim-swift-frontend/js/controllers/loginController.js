angular.module('claimSwiftApp')
    .controller('LoginController', ['$scope', '$window', '$timeout', 'AuthService', 'UserService',
        function($scope, $window, $timeout, AuthService, UserService) {
            
            $scope.credentials = {
                email: '',
                password: '',
                role: ''
            };
            
            $scope.errorMessage = '';
            
            $scope.login = function() {
                $scope.errorMessage = '';
                
                AuthService.login($scope.credentials).then(function(response) {
                    if (response.data.message === 'Login Successful') {
                        // Store user data in UserService (shared across pages)
                        UserService.setCurrentUser(response.data.user);
                        
                        // Also try sessionStorage as fallback
                        try {
                            $window.sessionStorage.setItem('user', JSON.stringify(response.data.user));
                        } catch(e) {
                            console.warn('sessionStorage not available, using service storage only');
                        }
                        
                        // Redirect based on role after a short delay
                        $timeout(function() {
                            if (response.data.user.role === 'USER') {
                                $window.location.href = 'views/user-dashboard.html';
                            } else if (response.data.user.role === 'AGENT') {
                                $window.location.href = 'views/agent-dashboard.html';
                            }
                        }, 300);
                    }
                }, function(error) {
                    $scope.errorMessage = error.data.message || 'Login failed. Please try again.';
                });
            };
        }
    ]);