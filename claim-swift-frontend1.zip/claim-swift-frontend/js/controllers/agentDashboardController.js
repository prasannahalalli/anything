angular.module('claimSwiftApp')
    .controller('AgentDashboardController', ['$scope', '$window', '$interval', 'ClaimService', 'UserService',
        function($scope, $window, $interval, ClaimService, UserService) {
            
            // Get user from UserService first, fallback to sessionStorage
            $scope.user = UserService.getCurrentUser();
            if (!$scope.user) {
                try {
                    $scope.user = JSON.parse($window.sessionStorage.getItem('user'));
                } catch(e) {
                    $scope.user = null;
                }
            }
            
            $scope.claims = [];
            
            // Check if user is logged in and is an agent
            if (!$scope.user || $scope.user.role !== 'AGENT') {
                $window.location.href = '../index.html';
                return;
            }
            
            // Load all claims
            $scope.loadClaims = function() {
                ClaimService.getAllClaims().then(function(response) {
                    $scope.claims = response.data;
                });
            };
            
            // Initial load
            $scope.loadClaims();
            
            // Auto-refresh claims every 3 seconds for real-time updates
            var refreshInterval = $interval(function() {
                $scope.loadClaims();
            }, 3000);
            
            // Clean up interval on page leave
            $scope.$on('$destroy', function() {
                if (refreshInterval) {
                    $interval.cancel(refreshInterval);
                }
            });
            
            $scope.viewClaim = function(claimId) {
                $window.location.href = 'claim-details.html?id=' + claimId;
            };
            
            $scope.logout = function() {
                UserService.logout();
                try {
                    $window.sessionStorage.clear();
                } catch(e) {
                    console.warn('Could not clear sessionStorage');
                }
                $window.location.href = '../index.html';
            };
        }
    ]);