angular.module('claimSwiftApp')
    .service('UserService', ['$http', '$window', 'API_BASE_URL', function($http, $window, API_BASE_URL) {
        
        var self = this;
        var currentUser = null;
        
        // Try to restore user from sessionStorage on init
        try {
            var stored = $window.sessionStorage.getItem('user');
            if (stored) {
                currentUser = JSON.parse(stored);
            }
        } catch(e) {
            console.warn('Could not access sessionStorage');
        }
        
        this.getCurrentUser = function() {
            return currentUser;
        };
        
        this.setCurrentUser = function(user) {
            currentUser = user;
        };
        
        this.isLoggedIn = function() {
            return currentUser !== null;
        };
        
        this.logout = function() {
            currentUser = null;
            try {
                $window.sessionStorage.removeItem('user');
            } catch(e) {
                console.warn('Could not access sessionStorage');
            }
        };
        
        this.getUserById = function(userId) {
            return $http.get(API_BASE_URL + '/user/' + userId);
        };
        
    }]);