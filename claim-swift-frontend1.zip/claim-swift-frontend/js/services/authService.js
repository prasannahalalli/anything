angular.module('claimSwiftApp')
    .service('AuthService', ['$http', '$q', 'API_BASE_URL', function($http, $q, API_BASE_URL) {
        
        var self = this;
        var USE_MOCK_API = true; // Set to false when backend is ready
        
        // Mock user data for testing
        var mockUsers = {
            USER: {
                id: 1,
                username: 'TestUser',
                email: 'test@example.com',
                role: 'USER',
                contactNumber: '9876543210',
                insuranceNumber: 'INS12345',
                vehicleNumber: 'MH01AB1234'
            },
            AGENT: {
                id: 2,
                username: 'Agent007',
                email: 'agent@example.com',
                role: 'AGENT',
                contactNumber: '9123456789',
                insuranceNumber: 'AGT98765',
                vehicleNumber: 'MH02CD5678'
            }
        };
        
        this.login = function(credentials) {
            if (USE_MOCK_API) {
                // Mock login: accept any credentials and return sample user based on role
                if (credentials.role && (credentials.role === 'USER' || credentials.role === 'AGENT')) {
                    return $q.resolve({
                        data: {
                            message: 'Login Successful',
                            user: mockUsers[credentials.role]
                        }
                    });
                } else {
                    return $q.reject({
                        data: {
                            message: 'Please select a valid role.'
                        }
                    });
                }
            } else {
                // Real backend call
                return $http.post(API_BASE_URL + '/auth/login', credentials);
            }
        };
        
    }]);