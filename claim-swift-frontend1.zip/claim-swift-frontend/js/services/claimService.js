angular.module('claimSwiftApp')
    .service('ClaimService', ['$http', '$q', 'API_BASE_URL', function($http, $q, API_BASE_URL) {
        
        var USE_MOCK_API = true; // Set to false when backend is ready
        
        // Mock claims data for testing
        var mockClaims = [
            {
                id: 1,
                userId: 1,
                status: 'PENDING',
                createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
                imagePath: '/images/damage1.jpg',
                pdfPath: '/docs/estimate1.pdf',
                user: {
                    id: 1,
                    username: 'TestUser',
                    email: 'test@example.com',
                    contactNumber: '9876543210',
                    insuranceNumber: 'INS12345',
                    vehicleNumber: 'MH01AB1234'
                },
                totalEstimation: 15000,
                claimParts: [
                    { partName: 'Front Bumper', amount: 5000 },
                    { partName: 'Headlight', amount: 3000 },
                    { partName: 'Bonnet', amount: 7000 }
                ]
            },
            {
                id: 2,
                userId: 1,
                status: 'APPROVED',
                createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
                imagePath: '/images/damage2.jpg',
                pdfPath: null,
                user: {
                    id: 1,
                    username: 'TestUser',
                    email: 'test@example.com',
                    contactNumber: '9876543210',
                    insuranceNumber: 'INS12345',
                    vehicleNumber: 'MH01AB1234'
                },
                totalEstimation: 25000,
                claimParts: [
                    { partName: 'Door', amount: 12000 },
                    { partName: 'Mirror', amount: 2000 },
                    { partName: 'Paint Job', amount: 11000 }
                ]
            },
            {
                id: 3,
                userId: 1,
                status: 'DISAPPROVED',
                createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
                imagePath: '/images/damage3.jpg',
                pdfPath: null,
                user: {
                    id: 1,
                    username: 'TestUser',
                    email: 'test@example.com',
                    contactNumber: '9876543210',
                    insuranceNumber: 'INS12345',
                    vehicleNumber: 'MH01AB1234'
                },
                totalEstimation: 0,
                claimParts: []
            }
        ];
        
        this.createClaim = function(formData) {
            if (USE_MOCK_API) {
                return $q.resolve({ data: { message: 'Claim created successfully', id: 4 } });
            }
            return $http.post(API_BASE_URL + '/claims/create', formData, {
                headers: {'Content-Type': undefined},
                transformRequest: angular.identity
            });
        };
        
        this.getAllClaims = function() {
            if (USE_MOCK_API) {
                return $q.resolve({ data: mockClaims });
            }
            return $http.get(API_BASE_URL + '/claims/all');
        };
        
        this.getClaimsByUser = function(userId) {
            if (USE_MOCK_API) {
                var userClaims = mockClaims.filter(function(claim) {
                    return claim.userId === userId;
                });
                return $q.resolve({ data: userClaims });
            }
            return $http.get(API_BASE_URL + '/claims/user/' + userId);
        };
        
        this.getClaimById = function(claimId) {
            if (USE_MOCK_API) {
                var claim = mockClaims.find(function(c) {
                    return c.id === claimId;
                });
                return $q.resolve({ data: claim || {} });
            }
            return $http.get(API_BASE_URL + '/claims/' + claimId);
        };
        
        this.approveClaim = function(claimId, parts) {
            if (USE_MOCK_API) {
                return $q.resolve({ data: { message: 'Claim approved successfully' } });
            }
            return $http.post(API_BASE_URL + '/claims/' + claimId + '/approve', parts);
        };
        
        this.disapproveClaim = function(claimId) {
            if (USE_MOCK_API) {
                return $q.resolve({ data: { message: 'Claim disapproved successfully' } });
            }
            return $http.post(API_BASE_URL + '/claims/' + claimId + '/disapprove');
        };
        
    }]);